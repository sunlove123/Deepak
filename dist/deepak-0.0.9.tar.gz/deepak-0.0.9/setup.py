from setuptools import setup

setup(name='deepak',
      version='0.0.9',
      description='test Installation Module',
      url='http://github.com/sunlove123',
      author='DeenaDhayalan',
      author_email='deenadhayalan.b.cts@gmail.com',
      license='MIT',
      packages=['deepak'],
      zip_safe=False)
